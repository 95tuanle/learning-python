import os
import shutil
from os import path
from zipfile import ZipFile


def main():
    # if path.exists("textfile.txt"):
    if path.exists("textfile.txt.bak"):
        src = path.realpath("textfile.txt")

        # dst = src + ".bak"
        # shutil.copy(src, dst)

        # os.rename("textfile.txt", "newfile.txt")

        root_dir, tail = path.split(src)
        print("root dir: " + root_dir)
        print("tail: " + tail)

        shutil.make_archive("archive", "zip", root_dir)

        with ZipFile("testzip.zip", "w") as new_zip:
            new_zip.write("newfile.txt")
            new_zip.write("textfile.txt.bak")


if __name__ == "__main__":
    main()
